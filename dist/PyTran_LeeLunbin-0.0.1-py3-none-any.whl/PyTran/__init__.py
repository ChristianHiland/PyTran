Version = float(0.1)
Release = int(1)

# Importing modules
from PyTran.English import English
from PyTran.Run import Start
import os

# Vars
